package Model;

public class InfoPramuka {
    void dataAnggota();
}
