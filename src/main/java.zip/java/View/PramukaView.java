package View;


import Controller.PramukaController;
import Model.AnggotaPramuka;
import Model.GugusDepan;
import Model.Kwarran;
import Model.Siswa;
import Model.Pembina;
import java.util.Scanner;


public class PramukaView {
    private Scanner input = new Scanner(System.in);
    private PramukaController controller;
    
    public PramukaView(PramukaController controller) {
        this.controller = controller; 
    }
    
    public void mulai(){
        int pilihan = 0;
        do{
            System.out.println("=== Keanggotaan Pramuka ===");
            System.out.println("1. Gugus Depan");
            System.out.println("2. Kwartir Ranting");
            System.out.println("3. Anggota Pramuka");
            System.out.println("4. Keluar");
            System.out.print("Masukkan Pilihan: ");
            
            if (input.hasNextInt()){
                pilihan = input.nextInt();
                input.nextLine();
            } else {
                System.out.println("Input harus angka");
                input.nextLine();
                continue;
            }
            
            switch (pilihan) {
                case 1: menuGudep();
                break;
                
                case 2: menuKwarran();
                break;
                
                case 3: menuAnggota();
                break;
                
                case 4: System.out.println("Program Selesai");
                    break;
                    
                default: System.out.println("Input Tidak Valid");
            }
        } while (pilihan !=4);
    }
    
    
    private void menuGudep(){
        System.out.println("=== GUGUS DEPAN ===");
        System.out.println("1. Tambah Gugus Depan");
        System.out.println("2. Lihat Gugus Depan");
        System.out.println("Pilih Menu: ");
        
        int pilihan = input.nextInt();
        input.nextLine();
        
        if (pilihan == 1) {
            System.out.print("Kode Gugus Depan: "); int kodeGugusDepan = input.nextInt(); input.nextLine();
            System.out.print("Nama Gugus Depan: "); String namaGugusDepan = input.nextLine();
            System.out.print("Pangkalan: "); String pangkalan = input.nextLine();
            controller.tambahGudep(kodeGugusDepan, namaGugusDepan, pangkalan);
            System.out.println("Data Gugus Depan Berhasil Ditambahkan!");
        } else if (pilihan == 2) {
            for (int i = 0; i < controller.getGugusDepanList().size(); i++) {
                System.out.println((i+1) + ".");
                controller.getGugusDepanList().get(i).tampilkanData();
            }
        }
    }
    
    private void menuKwarran(){
        System.out.println("=== Kwartir Ranting ===");
        System.out.println("1. Tambah Kwartir Ranting");
        System.out.println("2. Lihat Kwartir Ranting");
        System.out.println("Pilih Menu: ");
        
        int pilihan = input.nextInt();
        input.nextLine();
        
        if (pilihan == 1) {
            System.out.println("ID Kwartir Ranting: "); int idKwarran = input.nextInt(); input.nextLine();
            System.out.println("Nama Kwartir Ranting: "); String namaKwarran = input.nextLine();
            controller.tambahKwarran(idKwarran, namaKwarran);
            System.out.println("Data Kwartir Ranting Berhasil Ditambahkan!");
        } else if (pilihan == 2) {
            for (int i = 0; i < controller.getKwarranList().size(); i++) {
                System.out.println((i+1) + ".");
                controller.getKwarranList().get(i).tampilkanData();
            }
        }
    }
    
    private void menuAnggota(){
        System.out.println("1. Tambah Anggota");
        System.out.println("2. Lihat Anggota");
        System.out.print("Pilih Menu: ");
        int pilihan = input.nextInt(); input.nextLine();
        if (pilihan == 1){
            System.out.println("Jenis Anggota: ");
            System.out.println("1. Siswa");
            System.out.println("2. Pembina");
            System.out.print("Masukkan Pilihan: "); int jenis = input.nextInt(); input.nextLine();
            System.out.print("ID Anggota: "); int idAnggota = input.nextInt(); input.nextLine();
            System.out.print("Nama Anggota: "); String namaAnggota = input.nextLine();
            System.out.print("Jenis Kelamin: "); String jenisKelamin = input.nextLine();
            System.out.print("Kode Gugus Depan: "); int kodeGugusDepan = input.nextInt(); input.nextLine();
            System.out.print("ID Kwartir Ranting: "); int idKwarran = input.nextInt(); input.nextLine();
            
            if (jenis == 1) {
                System.out.print("Tingkat Pramuka: "); String tingkatPramuka = input.nextLine();
                controller.tambahSiswa(idAnggota, namaAnggota, jenisKelamin, kodeGugusDepan, idKwarran, tingkatPramuka);
            } else {
                System.out.print("Hak Bina: "); String hakBina = input.nextLine();
                controller.tambahPembina(idAnggota, namaAnggota, jenisKelamin, kodeGugusDepan, idKwarran, hakBina);
            }
            System.out.println("Anggota Pramuka Berhasil Ditambahkan");
        } else if (pilihan == 2) {
            for (int i = 0; i < controller.getAnggotaList().size(); i++) {
                System.out.println("Nomor: " + (i+1));
                controller.getAnggotaList().get(i).tampilkanData(); 
                System.out.println("---------------------------");
            }
        }
    }
}
