package Controller;

import java.util.ArrayList;
import java.util.Scanner;
import Model.AnggotaPramuka;
import Model.Siswa;
import Model.Pembina;
import Model.Kwarran;
import Model.GugusDepan;

public class PramukaController {
    private final ArrayList<AnggotaPramuka> anggotaPramuka = new ArrayList<>();
    private final ArrayList<GugusDepan> gugusDepan = new ArrayList<>();
    private final ArrayList<Kwarran> kwarran = new ArrayList<>();
    
    public PramukaController() {
        gugusDepan.add(new GugusDepan(1122, "Ki Hajar Dewantara - Dewi Sartika", "SMAN 1 Berau"));
        kwarran.add(new Kwarran(170301, "Tanjung Redeb"));
        anggotaPramuka.add(new Siswa(1001, "Farel Awaluddin", "Laki-Laki", 1122, 170301, "Penegak"));
        anggotaPramuka.add(new Pembina(2001, "Pak Kaspul Anwar", "Laki-Laki", 1122, 170301, "KMD"));
    }
    
    public ArrayList<GugusDepan> getGugusDepanList() { return gugusDepan; }
    public ArrayList<Kwarran> getKwarranList() { return kwarran; }
    public ArrayList<AnggotaPramuka> getAnggotaList() { return anggotaPramuka; }

    public void tambahGudep(int kodeGugusDepan, String namaGugusDepan, String pangkalan) {
        gugusDepan.add(new GugusDepan(kodeGugusDepan, namaGugusDepan, pangkalan));
    }

    public void tambahKwarran(int idKwarran, String namaKwarran) {
        kwarran.add(new Kwarran(idKwarran, namaKwarran));
    }

    public void tambahSiswa(int idAnggota, String namaAnggota, String jenisKelamin, int kodeGugusDepan, int idKwarran, String tingkatPramuka) {
        anggotaPramuka.add(new Siswa(idAnggota, namaAnggota, jenisKelamin, kodeGugusDepan, idKwarran, tingkatPramuka));
    }

    public void tambahPembina(int idAnggota, String namaAnggota, String jenisKelamin, int kodeGugusDepan, int idKwarran, String hakBina) {
        anggotaPramuka.add(new Pembina(idAnggota, namaAnggota, jenisKelamin, kodeGugusDepan, idKwarran, hakBina));
    }
}
